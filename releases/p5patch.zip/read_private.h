#ifndef __READ_H__
#define __READ_H__

#include "interrupts_private.h"

int miniterm_initialize();

#endif /*__READ_H__*/